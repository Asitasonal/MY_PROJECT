let tasks = JSON.parse(localStorage.getItem('tasks')) || [];

// Function to render tasks
function renderTasks(filter = 'all') {
    const todoList = document.getElementById('todoList');
    todoList.innerHTML = '';

    tasks.forEach((task, index) => {
        if (filter === 'pending' && task.completed) return;
        if (filter === 'completed' && !task.completed) return;

        const listItem = document.createElement('li');
        listItem.classList.toggle('completed', task.completed);

        const content = document.createElement('div');
        content.innerHTML = `<strong>${task.title}:</strong> ${task.description}`;
        listItem.appendChild(content);

        // Complete Button
        const completeBtn = document.createElement('button');
        completeBtn.innerText = task.completed ? 'Undo' : 'Complete';
        completeBtn.classList.add('completeBtn');
        completeBtn.addEventListener('click', function() {
            tasks[index].completed = !tasks[index].completed;
            renderTasks(filter);
        });
        listItem.appendChild(completeBtn);

        
        // Delete Button
        const deleteBtn = document.createElement('button');
        deleteBtn.innerText = 'Delete';
        deleteBtn.classList.add('deleteBtn');
        deleteBtn.addEventListener('click', function() {
            tasks.splice(index, 1);
            renderTasks(filter);
        });
        listItem.appendChild(deleteBtn);

        todoList.appendChild(listItem);
    });
}

// Add Task
document.getElementById('addBtn').addEventListener('click', function() {
    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;

    if (title === '' || description === '') {
        alert('Please add both a title and a description.');
        return;
    }

    const date = new Date().toLocaleDateString();

    tasks.push({ title, description, completed: false, date });
    renderTasks();

    // Clear input fields
    document.getElementById('title').value = '';
    document.getElementById('description').value = '';
});

// Save tasks to local storage
document.getElementById('saveBtn').addEventListener('click', function() {
    localStorage.setItem('tasks', JSON.stringify(tasks));
    alert('Tasks saved!');
});

// Filter pending tasks
document.getElementById('pendingBtn').addEventListener('click', function() {
    renderTasks('pending');
});

// Filter completed tasks
document.getElementById('completedBtn').addEventListener('click', function() {
    renderTasks('completed');
});

// Initial render
renderTasks();
