let display = document.getElementById('display');
let lastAns = '';

function appendToDisplay(value) {
    display.value += value;
}

function clearDisplay() {
    display.value = '';
}

function deleteChar() {
    display.value = display.value.slice(0, -1);
}

function calculate() {
    try {
        let result = eval(display.value.replace('√', 'Math.sqrt'));
        lastAns = result;
        display.value = result;
    } catch (error) {
        display.value = 'Error';
    }
}

function squareRoot() {
    display.value += '√';
}

function previousAns() {
    display.value += lastAns;
}
